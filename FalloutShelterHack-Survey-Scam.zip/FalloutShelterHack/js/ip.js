	window.onload = function() {
            var webService = "http://www.jsonip.com/json";
            var script = document.createElement("script");
            script.type = "text/javascript";
            script.src = webService + "?callback=MyIP";
            document.getElementsByTagName("head")[0].appendChild(script);
        };

        function MyIP(response) {
            document.getElementById("ip").innerHTML = response.ip;
        }
        var eenum = 420;
        var ee;

        function dis_num2() {
            document.getElementById("online").innerHTML = eenum;
            var randWay = Math.floor(Math.random() * 10 + 1);
            if (randWay <= 5) {
                eenum = eenum + Math.floor(Math.random() * 10 + 1);;
            } else {
                eenum = eenum - Math.floor(Math.random() * 10 + 1);;
            }
            ee = setTimeout("dis_num2()", 3000);
        }
        dis_num2();


        document.getElementById("para1").innerHTML = formatAMPM();

        function formatAMPM() {
            var d = new Date(),

                hours = d.getHours().toString().length == 1 ? '0' + d.getHours() : d.getHours(),
                ampm = d.getHours() >= 12 ? 'pm' : 'am',
                months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            return months[d.getMonth()] + ' ' + d.getDate() + ' ' + d.getFullYear() + ' ';
        }