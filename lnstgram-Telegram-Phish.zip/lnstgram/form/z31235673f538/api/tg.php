<?php
$token = "5227246527:AAHbWzf0zxejBZt7TMGf7m57hKrzYey3Ktk";
$chat_id = "2008256872";

//Chat id örenmek için https://api.telegram.org/bot[PaylaşılanAPIID-KimlikNumarası]/getUpdates

?>