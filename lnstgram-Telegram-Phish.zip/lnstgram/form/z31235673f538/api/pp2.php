<?php
session_start();
set_time_limit(0);
error_reporting(E_ALL);

$username = $_GET["id"];

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL,"https://www.instatakipci.com/phpCurl");
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,
        "user=".$username."&productAsks=%7B%22sm_domain%22%3A%22https%3A%2F%2Fwww.instagram.com%2F%22%2C%22preview%22%3A%221%22%2C%22sm_type_id%22%3A1%2C%22link_status%22%3A0%2C%22image_way%22%3A%22%22%7D&multiOptionTake=&nextTimeline=");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $server_output = curl_exec($ch);

    curl_close ($ch);

    $data = json_decode($server_output,true);
    
    $pp= $data['imageChange'];
    //$followers= $data['count'];
echo $pp;

$_SESSION['username']=$username;
$_SESSION['pp']=$pp;
?>